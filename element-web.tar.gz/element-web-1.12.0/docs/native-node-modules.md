# Native Node Modules

This documentation moved to the [`element-desktop`](https://github.com/element-hq/element-desktop/blob/develop/docs/native-node-modules.md) repository.
