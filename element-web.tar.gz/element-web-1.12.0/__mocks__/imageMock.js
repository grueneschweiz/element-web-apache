module.exports = "image-file-stub";
