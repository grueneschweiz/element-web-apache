export const Icon = "div";
export default "image-file-stub";
