module.exports = require("eslint-plugin-matrix-org/.prettierrc.js");
